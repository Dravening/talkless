#!/bin/bash
cd C:/myprogram/elasticsearch-head-5.0.0
echo "当前目录C:/myprogram/elasticsearch-head-5.0.0"

echo "执行npm install"
npm install

echo "执行grunt server"
grunt server
# 此时已启动，请访问http://localhost:9100